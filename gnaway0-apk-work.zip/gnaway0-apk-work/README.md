# Berlin / gnaway0 APK build attempt

This repository is a GitHub Actions build scaffold for the uploaded Berlin APK.

## Setup
1. Create a GitHub repository and upload this folder's contents.
2. Put the original APK in the repository root named `Berlin-original.apk` (or use the workflow's file input).
3. Open **Actions** and run **Android APK rebuild attempt**.
4. Download the `apk-output` artifact if the workflow succeeds.

## What this attempt does
- Installs Android build/reverse-engineering tools on the runner.
- Decodes the APK with apktool and scans decoded files for `randomkzn` text.
- Attempts a safe text/label replacement to `gnaway0` where it finds editable decoded resources.
- Rebuilds and signs the APK, then verifies it.
- Uploads build logs and the APK as an artifact.

## Important limitations
The provided APK is a Unity IL2CPP build, not the Unity project. This scaffold does **not** implement the Subway Surfers in-game configuration menu, a functional key overlay, or a reliable game-FPS overlay. Those require modifying/rebuilding the game's Unity/IL2CPP code or adding a native overlay implementation and testing it on-device. The workflow is an honest first pass and records what it can patch; it does not claim those widgets are present.
