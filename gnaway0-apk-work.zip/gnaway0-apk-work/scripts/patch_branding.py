#!/usr/bin/env python3
"""Conservative text-only patch attempt in apktool-decoded resources."""
from pathlib import Path
import re
import sys

root = Path(sys.argv[1])
count = 0
files = []
for p in root.rglob('*'):
    if not p.is_file():
        continue
    try:
        data = p.read_text(encoding='utf-8')
    except (UnicodeDecodeError, OSError):
        continue
    if 'randomkzn' not in data.lower():
        continue
    patched = re.sub('randomkzn', 'gnaway0', data, flags=re.IGNORECASE)
    if patched != data:
        p.write_text(patched, encoding='utf-8')
        count += patched.lower().count('gnaway0') - data.lower().count('gnaway0')
        files.append(str(p))

print(f'Files changed: {len(files)}')
for f in files:
    print(f'PATCHED: {f}')
if not files:
    print('No editable decoded text references to randomkzn were found. Branding may be stored in binary assets or IL2CPP code.')
